package com.example.dbopenhelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static  final String DBNAME=" mydb.db";
    public static  final int VERSION=1;
    SQLiteDatabase myDB;

    public static  final String TABLENAME="employee";
    public static  final String ID="id";
    public static  final String NAME="name";
    public static  final String SALARY= "salary";


    public DBHelper(Context context) {

        super(context, DBNAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table  if not exists employee(id varchar(10),name varchar(10),salary varchar(10))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public  void OpenDB()
    {
        myDB=getWritableDatabase();
    }
    public  void CloseDB()
    {
        if( myDB.isOpen())
            myDB.close();
    }

    public long Insert(String id2,String nm,String sal)
    {
        ContentValues values=new ContentValues();
        values.put(ID,id2);
        values.put(NAME,nm);
        values.put(SALARY,sal);

        return myDB.insert(TABLENAME,null,values);

    }

    public long Update(String id2,String nm,String sal)
    {
        ContentValues values=new ContentValues();
        values.put(NAME,nm);
        values.put(SALARY,sal);

        String where= ID + " = " + id2;

        return myDB.update(TABLENAME,values,where,null);

    }

    public long Delete(String id2)
    {
        String where= ID + " = " + id2;

        return myDB.delete(TABLENAME,where,null);

    }

    public Cursor getAllRecords()
    {
        String query="SELECT * FROM " + TABLENAME;
        Cursor c= myDB.rawQuery(query,null);
        return  c;
    }


}
