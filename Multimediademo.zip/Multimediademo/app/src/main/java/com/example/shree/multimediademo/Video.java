package com.example.shree.multimediademo;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class Video extends AppCompatActivity {

    VideoView v;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        v=findViewById(R.id.videoView);
        b=findViewById(R.id.button);

        String s1="android.resource://com.example.shree.multimediademo/"+R.raw.vdo;
        Uri uri=Uri.parse(s1);
        v.setVideoURI(uri);
        MediaController m=new MediaController(Video.this);
        v.setMediaController(m);
        v.requestFocus();
        v.start();
    }
}
