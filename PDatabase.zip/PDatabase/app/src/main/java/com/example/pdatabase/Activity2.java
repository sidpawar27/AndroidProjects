package com.example.pdatabase;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Activity2 extends AppCompatActivity {
EditText e1,e2;
Myhelper mh;
SharedPreferences prf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        e1= findViewById(R.id.editText3);
        e2= findViewById(R.id.editText4);
        mh = new Myhelper(this);
//        Intent i = new Intent(Activity2.this,Activity3.class);
      //   prf = getSharedPreferences("User_name",MODE_PRIVATE);
        prf = getSharedPreferences("User_name",MODE_PRIVATE);
       /* Intent i = new Intent(Activity2.this,Activity3.class);
        if(prf.contains("username") && prf.contains("password"))
        {
            startActivity(i);
        }*/

    }
    public void Login(View view)
    {
        int flg=0;
        Cursor ch= mh.fetch();
        String unm = e1.getText().toString();
        String pas = e2.getText().toString();

        while(ch.moveToNext())
        {
                if(unm.equals(ch.getString(0)) && pas.equals(ch.getString(1)))
                {
                    SharedPreferences.Editor editor = prf.edit();
                    editor.putString("username",e1.getText().toString());
                    editor.putString("password",e2.getText().toString());
                    editor.commit();
                    flg=1;
                }
        }
        if(flg==1)
        {

            Toast.makeText(getApplicationContext(),"Ok",Toast.LENGTH_LONG).show();
            Intent i1 = new Intent(Activity2.this,Activity3.class);
            startActivity(i1);

        }else
        {
            Toast.makeText(getApplicationContext(),"Invalid user",Toast.LENGTH_LONG).show();
        }
    }
}
