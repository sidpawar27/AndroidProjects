package com.example.pdatabase;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText Name, Pass;
Button Login,Register;
Myhelper mh;
SharedPreferences prf;
Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Name=findViewById(R.id.editText);
        Pass = findViewById(R.id.editText2);
        Login = findViewById(R.id.button2);
        Register = findViewById(R.id.button);

        mh = new Myhelper(this);

        prf = getSharedPreferences("User_name",MODE_PRIVATE);
         i = new Intent(MainActivity.this,Activity3.class);
        if(prf.contains("username") && prf.contains("password"))
        {
            startActivity(i);
        }
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mh.insertdata(Name.getText().toString(),Pass.getText().toString());
                Log.i("insert data","onclick values inserted");

            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i1 = new Intent(MainActivity.this,Activity2.class);

                startActivity(i1);
            }
        });

    }
}
