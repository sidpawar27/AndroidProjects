package com.example.pdatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Myhelper extends SQLiteOpenHelper {

    public Myhelper(Context context) {
        super(context, "DB.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Login(name varchar(15),pass varchar(15))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertdata(String s1, String s2) {
        SQLiteDatabase db1 = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", s1);
        v.put("pass", s2);

        db1.insert("Login", null, v);
    }

    public Cursor fetch() {
        SQLiteDatabase db2 = getWritableDatabase();
           Cursor c = db2.rawQuery("select * from Login", null);
    return c ;
    }
}
