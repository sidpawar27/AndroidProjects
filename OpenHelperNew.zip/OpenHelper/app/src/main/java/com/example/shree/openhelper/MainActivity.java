package com.example.shree.openhelper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText Name, Pass;
    Button Login,Register;
    MyHelper mh;
    Intent i;
    TextView tv;
    String unm,pas;

    SharedPreferences prf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = findViewById(R.id.editText);
        Pass = findViewById(R.id.editText2);
        Login = findViewById(R.id.button2);
        Register = findViewById(R.id.button);

        mh = new MyHelper(this);
        prf = getSharedPreferences("User_name",MODE_PRIVATE);
        i = new Intent(MainActivity.this,Activity3.class);
        if(prf.contains("username") && prf.contains("password"))
        {
            startActivity(i);
        }
      //  unm=Name.getText().toString();
     //   pas=Pass.getText().toString();

        Register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                mh.insertdata(Name.getText().toString(),Pass.getText().toString());
                Toast.makeText(getApplicationContext(), ""+Name.getText().toString()+"", Toast.LENGTH_LONG).show();
            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Cursor cursor =mh.fetch();
                String unm=Name.getText().toString();
                String pass=Pass.getText().toString();
                while (cursor.moveToNext())
                {

                    Toast.makeText(getApplicationContext(), "  Success ", Toast.LENGTH_LONG).show();
                    if(unm.equals(cursor.getString(0)) && pass.equals(cursor.getString(1))){

                        Intent i=new Intent(MainActivity.this,Activity2.class);
                        startActivity(i);


                    }
                }*/

                Intent i=new Intent(MainActivity.this,Activity2.class);
                startActivity(i);

            }
        });
    }
}
