package com.example.externalstorage;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    EditText e1;
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        b1=findViewById(R.id.button2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String state= Environment.getExternalStorageState();
                if(Environment.MEDIA_MOUNTED.equals(state)){
                    File root=Environment.getExternalStorageDirectory();
                    File Dir=new File(root.getAbsolutePath()+"/myfile");
                    if(!Dir.exists()){
                        Dir.mkdir();
                    }
                    File file=new File(Dir,"file.txt");
                    String message=e1.getText().toString();
                    try{
                        FileOutputStream fos=new FileOutputStream(file);
                        fos.write(message.getBytes());
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(),"NO",Toast.LENGTH_LONG);

                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File root=Environment.getExternalStorageDirectory();
                File Dir=new File(root.getAbsolutePath()+"/myfile");
                File file=new File(Dir,"file.txt");
                String msg;
                try{
                    FileInputStream fis=new FileInputStream(file);
                    InputStreamReader isr=new InputStreamReader(fis);
                    BufferedReader br=new BufferedReader(isr);
                    StringBuffer sb=new StringBuffer();
                    while ((msg=br.readLine())!=null){
                        sb.append(msg+"\n");
                    }
                    Toast.makeText(getApplicationContext(),sb.toString(),Toast.LENGTH_LONG).show();
                }
                catch (Exception e){

                }

            }
        });
    }
}
