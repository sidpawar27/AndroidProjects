package com.example.shree.openhelper;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Activity2 extends MainActivity {
    Button x;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        x=findViewById(R.id.button3);
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor cursor =mh.fetch();
                while (cursor.moveToNext()){
                    if(Name.getText().toString().equals(cursor.getString(0)) && Pass.getText().toString().equals(cursor.getString(1))){

                        Intent i=new Intent(getApplicationContext(),Activity2.class);
                        startActivity(i);
                        Toast.makeText(getApplicationContext(), "  Success ", Toast.LENGTH_LONG).show();

                    }
                }
            }
        });

    }
}
