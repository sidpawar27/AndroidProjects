package com.example.dbopenhelper;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DBHelper dbHelper;
    EditText e1,e2,e3,e4;
    Button b1,b2,b3,b4;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper=new DBHelper(MainActivity.this);
    e1=findViewById(R.id.editText);
    e2=findViewById(R.id.editText2);
    e3=findViewById(R.id.editText3);

    b1=findViewById(R.id.button);
    b2=findViewById(R.id.button2);
    b3=findViewById(R.id.button3);
    b4=findViewById(R.id.button4);

    tv=findViewById(R.id.textView);

    b1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            long result = dbHelper.Insert(getvalue(e1),getvalue(e2),getvalue(e3));
            if(result== -1)
            {
                Toast.makeText(getApplicationContext(),"Some errore happened while inserting",Toast.LENGTH_SHORT).show();

            }
            else
            {
                Toast.makeText(getApplicationContext(),"Successfully Inserted",Toast.LENGTH_SHORT).show();

            }
        }
    });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long resultUpdate =dbHelper.Update(getvalue(e1),getvalue(e2),getvalue(e3)) ;
                if(resultUpdate==0)
                {
                    Toast.makeText(getApplicationContext(),"Some errore happened while updating",Toast.LENGTH_SHORT).show();

                }
                else if(resultUpdate==1)
                {
                    Toast.makeText(getApplicationContext(),"Successfully Updated",Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Errors occured,multiple rows updated",Toast.LENGTH_SHORT).show();


                }
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long resultDelete =dbHelper.Delete(getvalue(e1));
                if(resultDelete==-0)
                {
                    Toast.makeText(getApplicationContext(),"Some errore happened while deliting",Toast.LENGTH_SHORT).show();

                }
                else if(resultDelete==1)
                {
                    Toast.makeText(getApplicationContext(),"Successfully Deleted",Toast.LENGTH_SHORT).show();

                }

            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer data= new StringBuffer();
                Cursor cursor =dbHelper.getAllRecords();
                for(cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext())
                {
                    data.append("  "+cursor.getString(0));
                    data.append("  "+cursor.getString(1));
                    data.append("  "+cursor.getString(2));
                    data.append("\n");
                }

                tv.setText(data);

            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();
        dbHelper.OpenDB();
        Toast.makeText(getApplicationContext(),"OpenDB called",Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        dbHelper.CloseDB();
    }

    public String getvalue(EditText edit)
    {

        return edit.getText().toString().trim();
    }
}
