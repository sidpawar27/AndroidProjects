package com.example.shree.openhelper;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity2 extends MainActivity {
    EditText e1,e2;
    MyHelper mh;
    SharedPreferences prf;
    Button x;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        x=findViewById(R.id.button3);
        e1= findViewById(R.id.editText3);
        e2= findViewById(R.id.editText4);
        mh = new MyHelper(this);
        prf = getSharedPreferences("User_name",MODE_PRIVATE);
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int flg=0;
                Cursor ch= mh.fetch();
                String unm = e1.getText().toString();
                String pas = e2.getText().toString();

                while(ch.moveToNext())
                {
                    if(unm.equals(ch.getString(0)) && pas.equals(ch.getString(1)))
                    {
                        SharedPreferences.Editor editor = prf.edit();
                        editor.putString("username",e1.getText().toString());
                        editor.putString("password",e2.getText().toString());
                        editor.commit();
                        flg=1;
                    }
                }
                if(flg==1)
                {

                    Toast.makeText(getApplicationContext(),"Ok",Toast.LENGTH_LONG).show();
                    Intent i1 = new Intent(Activity2.this,Activity3.class);
                    startActivity(i1);

                }else
                {
                    Toast.makeText(getApplicationContext(),"Invalid user",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
